package com.cg.health.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DBConnection {

	public static Connection getConnection() throws ClassNotFoundException, SQLException, IOException 
	{
		Properties properties = new Properties();
		FileInputStream fis = new FileInputStream("resources/db.properties");
		properties.load(fis);
		String driver = properties.getProperty("driver");
		String url = properties.getProperty("url");
		String username = properties.getProperty("user");
		String password = properties.getProperty("pwd");
		
		Class.forName(driver);
		Connection con=DriverManager.getConnection(url, username, password);
		
		
		return con;
		
	}
}
