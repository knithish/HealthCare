package com.cg.health.service;

import com.cg.health.exception.HealthCareException;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import com.cg.health.exception.HealthCareException;
import com.cg.health.bean.Patient;

public interface patientService 
{

	boolean validateDetails(Patient patient) throws HealthCareException;

	int fixAppointment(Patient patient) throws HealthCareException, IOException, SQLException, ClassNotFoundException;

	public Patient retrieveAll(int id)throws HealthCareException, IOException, ClassNotFoundException, SQLException;
}
