package com.cg.health.dao;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import com.cg.health.bean.Patient;
import com.cg.health.exception.HealthCareException;


public interface PatientDAO {

	int fixAppointment(Patient patient) throws HealthCareException, IOException, SQLException, ClassNotFoundException;
	public String getDoctorName(String problemName) throws HealthCareException, IOException, ClassNotFoundException, SQLException;
	public Patient retriveAll(int id) throws HealthCareException, ClassNotFoundException, SQLException, IOException;
}
