package com.cg.health.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.health.exception.HealthCareException;
import com.cg.health.bean.Patient;
import com.cg.health.util.DBConnection;
import com.cg.health.bean.Patient;
import com.cg.health.util.*;

public class patientDAOImpl implements PatientDAO 
{

	Connection connection = null;
	PreparedStatement statement = null;

	@Override
	public int fixAppointment(Patient patient) throws HealthCareException, IOException, SQLException, ClassNotFoundException 
	{      
		int patientId = 0;
	 
		Connection connection = DBConnection.getConnection();
     
	String doctorname = getDoctorName(patient.getProblem());
           
		if (!doctorname.isEmpty()) 
		{
			
				statement = connection.prepareStatement("insert into patients_table values(patient_sequence.nextval,?,?,?,?,sysdate+1)");
				statement.setString(1, patient.getName());
				statement.setLong(2, patient.getMobileNo());
				statement.setString(3, doctorname);
				statement.setString(4, patient.getProblem());
				statement.executeUpdate();
				

				statement = connection.prepareStatement("select max(patientid) from patients_table");
				ResultSet resultSet = statement.executeQuery();
				resultSet.next();
				patientId = resultSet.getInt(1);
			}
		return patientId;
	}
	public String getDoctorName(String doctorname) throws HealthCareException, IOException, SQLException, ClassNotFoundException 
	{
		connection = DBConnection.getConnection();
		//String doctorName = null;
		try 
	{
		statement = connection.prepareStatement("select doctorname from doctors_table where SPECIALIZATION =?");
			statement.setString(1, doctorname);
			ResultSet resultSet = statement.executeQuery();

			resultSet.next();

			doctorname = resultSet.getString(1);

		}
		catch (SQLException e) 
		{
			throw new HealthCareException("statement not created..");
		}

		return doctorname;

	}
	public Patient retriveAll(int id) throws ClassNotFoundException, SQLException, IOException
	{
		int patientId =id;
		System.out.println(id);
		connection=DBConnection.getConnection();
		Patient p=new Patient();
		try 
		{
			Statement st=connection.createStatement();
			ResultSet rs=st.executeQuery("select * from patients_table where patientid='"+patientId+"'");
			
			
				
				
				p.setId(rs.getInt(1));
				p.setName(rs.getString(2));
				p.setMobileNo(rs.getLong(3));
				p.setDoctorName(rs.getString(4));
				p.setProblem(rs.getString(5));
				p.setDate(rs.getDate(6));
				
				
			
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			System.out.println(e);
		}
		
		
		return p;
		
		
	}
	

}
