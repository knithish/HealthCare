package com.cg.health.pl;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cg.health.exception.HealthCareException;
import com.cg.health.service.patientServiceImpl;
import com.cg.health.bean.Patient;
import com.cg.health.dao.patientDAOImpl;
import com.cg.health.service.*;

public class Client 
{
	static Scanner sc=new Scanner(System.in);
	static patientService patientService=null;
	static patientServiceImpl patientServiceImpl=null;
	static patientDAOImpl patientdao=null;
	public static void main(String[] args) 
	{
		Patient patient =new Patient();
		int option=0;
		while(true)
			{
		System.out.println("welcome to  Health care Application");
		System.out.println("1.fix appoinment");
		System.out.println("2.search");
		System.out.println("3.Get Patient Details");
		System.out.println("4.exit");
		try 
		{
			option=sc.nextInt();
			switch (option)
			{
			case 1:
				while(patient==null)
				{
					patient=populatePatient();
				}
				try
				{
					int patientId=0;
					String doctorname=null;
					patientService=new patientServiceImpl();
					patientdao =new patientDAOImpl(); 
					patientId=patientService.fixAppointment(patient);
					System.out.println("Patient details are successfully registered");
					System.out.println("Your appoinment fixed with the id:" + patientId);
					System.out.println("Name of the Doctor for the specialization is:"+patientdao.getDoctorName(patient.getProblem()));
					System.out.println("Date Of Appointment is:"+patientdao);
				}
				catch(HealthCareException healthcareException)
				{
					System.out.println(healthcareException);
				}
				finally {
					//patientId=null;
					patientService=null;
					patient=null;
				}
				break;
			case 2:
				try 
				{
				patientdao =new patientDAOImpl(); 
				System.out.println("enter the problem:");
				String probName=sc.next();
				System.out.println("Name of the Doctor for the specialization is:"+patientdao.getDoctorName(probName));
				}
				catch(Exception e)
				{
					System.out.println(e);
				}
				break;
			case 3:
				try
				{
				
				System.out.println("enter the patientId:");
				int id=sc.nextInt();
				System.out.println("Details of the Patient for the given patientId");
				
				
				System.out.println(patientServiceImpl.retrieveAll(id));
				//System.out.println(patientdao.retriveAll());
				}
				catch(Exception e)
				{
					System.out.println(e);
				}
				break;
			case 4:
				System.out.println("Thank You");
				System.exit(0);
				break;
			default:
				System.out.println("please enter the above options!");
				break;
			}
			}
			
		catch(Exception e)
		{
		System.out.println(e);	
		}
		}
		
	}
	private static Patient populatePatient() throws ClassNotFoundException, IOException, SQLException 
	{
		Patient patient=new Patient();
		System.out.println("\nHealthCare Clinic");
		
		System.out.println("enter the patient name:");
		patient.setName(sc.next());
		
		System.out.println("enter the patient contact:");
		patient.setMobileNo(sc.nextLong());
		
		System.out.println("enter problem name");
		patient.setProblem(sc.next());
		
		
		patientServiceImpl =new patientServiceImpl();
		try
		{
			patientServiceImpl.fixAppointment(patient);
			return patient;
		}
		catch(HealthCareException healthcareException)
		{
			System.err.println("Invalid Dtat:");
			System.err.println( healthcareException.getMessage() + "\nTry again...");
		}
		return null;
	}
	
}




















