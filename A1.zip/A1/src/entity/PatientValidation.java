package entity;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PatientValidation extends Patient 
{
	public boolean isIdValid(String id) 
	{
		String idRegEx = "[1-9]{5}";
		Pattern pattern = Pattern.compile(id);
		Matcher matcher = pattern.matcher(id);
		return matcher.matches();
	}
	public boolean isNameValid(String name) 
	{
		String nameRegEx = "[A-Z]{1}[a-zA-Z]{5,20}";
		Pattern pattern = Pattern.compile(nameRegEx);
		Matcher matcher = pattern.matcher(name);
		return matcher.matches();
	}
	public boolean isAgeValid(String age) 
	{
		String ageRegEx = "[1-100]";
		Pattern pattern = Pattern.compile(ageRegEx);
		Matcher matcher = pattern.matcher(age);
		return matcher.matches();
	}
	public boolean isPhonevalid(String mobileNo) 
	{
		String phoneRegEx = "[0-9]{10}";
		Pattern pattern = Pattern.compile(phoneRegEx);
		Matcher matcher = pattern.matcher(String.valueOf(mobileNo));
		return matcher.matches();
	}
	public boolean isProblemValid(String problemName) 
	{
		String nameRegEx = "[a-zA-Z]{3,}";
		Pattern pattern = Pattern.compile(nameRegEx);
		Matcher matcher = pattern.matcher(problemName);
		return matcher.matches();
	}
}
