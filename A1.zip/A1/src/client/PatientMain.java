package client;
import java.util.Scanner;

import database.PatientDB;
import entity.Patient;
import entity.PatientValidation;

public class PatientMain 
{
public static void main(String[] args) 
{
	Patient p=new Patient();
	PatientValidation pv=new PatientValidation();
	PatientDB pdb=new PatientDB();
	Scanner sc=new Scanner(System.in);
	
	System.out.println("enter patientid");
	String id=sc.next();
	
	System.out.println("enter patient name");
	String patientname=sc.next();
	
	System.out.println("enter age");
	String age=sc.next();
	
	System.out.println("enter mobile");
	String mobileNo=sc.next();
	
	System.out.println("enter problem");
	String problem=sc.next();
	
	boolean pat=pv.isIdValid(id);
	boolean pat1=pv.isNameValid(patientname);
	boolean pat2=pv.isAgeValid(age);
	boolean pat3=pv.isPhonevalid(mobileNo);
	boolean pat4=pv.isProblemValid(problem);

	if(pat && pat1 && pat2 && pat3 && pat4)
	{
		int pid=Integer.parseInt(id);
		p.setPatientId(pid);
		int isAgeValid=Integer.parseInt(age);
		p.setAge(isAgeValid);
		long isPhonevalid=Long.parseLong(mobileNo);
		p.setPhone(isPhonevalid);
		pdb.DB(p);
	}
}
}
