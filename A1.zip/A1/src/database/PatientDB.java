package database;

import entity.Patient;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class PatientDB 
{
public void DB(Patient p)
{
	String url="jdbc:oracle:thin:@10.219.34.3:1521:orcl";
	String user="trg727";
	String pwd="training727";
	String query="insert into patient values(?,?,?,?,?)";
	String query1="select * from patient";
 try
 {
	Class.forName("oracle.jdbc.driver.OracleDriver");
	Connection con=DriverManager.getConnection(url,user,pwd);
	Statement st=con.createStatement();
	PreparedStatement ps=con.prepareStatement(query);
	
	ps.setInt(1, p.getPatientId());
	ps.setString(2, p.getPatientname());
	ps.setInt(3, p.getAge());
	ps.setLong(4, p.getPhone());
	ps.setString(5, p.getProblem());
	ps.executeUpdate();
	ResultSet rs=st.executeQuery(query1);
	
	while(rs.next())
	{
		System.out.println(rs.getInt(1)+" "+rs.getString(2)+" "+rs.getInt(3)+" "+rs.getLong(4)+" "+rs.getString(5));
	}
 } 
 
 catch (ClassNotFoundException | SQLException e) 
 {

	e.printStackTrace();
}	
}
}
