package service;

import exceptions.HealthCareException;
import entity.Patient;

public interface patientService {

	boolean validateDetails(Patient patient) throws HealthCareException;

	int fixAppointment(Patient patient) throws HealthCareException;

}
