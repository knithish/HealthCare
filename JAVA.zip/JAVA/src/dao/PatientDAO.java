package dao;

import exceptions.HealthCareException;
import entity.Patient;


public interface PatientDAO {

	int fixAppointment(Patient patient) throws HealthCareException;
	public String getDoctorName(String problemName) throws HealthCareException;

}
