package com.cg.donor.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.donor.bean.DonorBean;
import com.cg.donor.dao.IDonorDAO;
import com.cg.donor.dao.IDonorDAOImpl;
import com.cg.donor.exception.DonorException;

public class DonorServiceImpl implements IDonorService 
{
	IDonorDAO donordao=new IDonorDAOImpl();
	@Override
	public String addDonor(DonorBean donor) throws DonorException 
	{
		String donorSeq;
		donorSeq=donordao.addDonor(donor);
		return donorSeq;
	}

	@Override
	public DonorBean viewDonorDetails(String donorId) throws DonorException 
	{
		
		return null;
	}

	@Override
	public List retrieveAll() throws DonorException 
	{
		
		return null;
	}



public void validateDonar(DonorBean bean) throws DonorException
{
	List<String> validationErrors =new ArrayList<String>();
	
	if(!(isValidName(bean.getDonorName())))
	{
		validationErrors.add("\n Donor name should be in alphatical and min 3 char long!");
	}
	if(!(isValidAddress(bean.getAddress())))
	{
		validationErrors.add("\n Address should bve greater thean 5 characters");
	}
	if(!(isValidPhoneNumber(bean.getDonorNumber()))) 
	{
		validationErrors.add("\n phone number should be in 10 digit \n");
	}
	if(!(isValidAmount(bean.getDonationAmount())))
	{
		validationErrors.add("\n Amount should be a positive number \n");
	}
	if(!validationErrors.isEmpty())
	{
		throw new DonorException(validationErrors+ "");
	}
}

private boolean isValidAmount(double donationAmount)
{
	return donationAmount>0;
}

private boolean isValidPhoneNumber(String donorNumber) 
{
	Pattern phonePattern=Pattern.compile("^[6-9]{1}[0-9]{9}$");
	Matcher phonematcher=phonePattern.matcher(donorNumber);
	return phonematcher.matches();
}

private boolean isValidAddress(String address)
{

	return (address.length()>6);
}

private boolean isValidName(String donorName) 
{
	Pattern namePattern=Pattern.compile("^[A-Za-z]{3,}$");
	Matcher namematcher=namePattern.matcher(donorName);
	return namematcher.matches();
}

public boolean validateDonorId(String donorId)
{
	Pattern idPattern=Pattern.compile("[0-9]{1,4}");
	Matcher idmatcher=idPattern.matcher(donorId);
	
	if(idmatcher.matches())
		return true;
	else
		return false;
}
}


























