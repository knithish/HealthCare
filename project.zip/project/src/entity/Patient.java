package entity;

import java.util.Date;

public class Patient 
{
	private int patientId;
	private String patientname;
	private int age;
	private long phone;
	private String description;
	private Date consultationDate;
	
	public Patient()
	{
		super();
		// TODO Auto-generated constructor stub
	}
	public Patient(int patientId, String patientname, int age, long phone, String description,Date consultationDate) 
	{
		super();
		this.patientId = patientId;
		this.patientname = patientname;
		this.age = age;
		this.phone = phone;
		this.description = description;
		this.consultationDate = consultationDate;
	}
	
	public Patient(String patientname, int age, long phone, String description, Date consultationDate) 
	{
		super();
		this.patientname = patientname;
		this.age = age;
		this.phone = phone;
		this.description = description;
		this.consultationDate = consultationDate;
	}
	
	public int getPatientId() 
	{
		return patientId;
	}
	public void setPatientId(int patientId) 
	{
		this.patientId = patientId;
	}
	public String getPatientname() 
	{
		return patientname;
	}
	public void setPatientname(String patientname) 
	{
		this.patientname = patientname;
	}
	public int getAge() 
	{
		return age;
	}
	public void setAge(int age) 
	{
		this.age = age;
	}
	public long getPhone() 
	{
		return phone;
	}
	public void setPhone(long phone) 
	{
		this.phone = phone;
	}
	public String getDescription() 
	{
		return description;
	}
	public void setDescription(String description) 
	{
		this.description = description;
	}
	public Date getConsultationDate() 
	{
		return consultationDate;
	}
	public void setConsultationDate(Date consultationDate) 
	{
		this.consultationDate = consultationDate;
	}
	@Override
	public String toString() 
	{
		return "Patient [patientId=" + patientId + ", patientname=" + patientname + ", age=" + age + ", phone=" + phone
				+ ", description=" + description + ", consultationDate=" + consultationDate + "]";
	}
	
}
