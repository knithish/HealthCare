package service;

import java.sql.SQLException;
import entity.Patient;
import exception.HealthCareException;

public interface IPatient 
{
	int getId(Patient patient) throws HealthCareException, SQLException, ClassNotFoundException;
	public Patient getPatientById(int id) throws HealthCareException, ClassNotFoundException, SQLException;
}
