package service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import entity.Patient;
import exception.HealthCareException;


public class PatientDA implements IPatient
{
	Connection connection = null;
	PreparedStatement statement = null;
	@Override
	public int getId(Patient patient) throws HealthCareException, SQLException, ClassNotFoundException
	{
		String url="";
		String user="";
		String pwd="";
		int patientId = 0 ;
		Class.forName("");
		Connection connnection=DriverManager.getConnection("","","");
		try
			{
				statement = connection.prepareStatement("");
				statement.setString(1, patient.getPatientname());
				statement.setInt(2, patient.getAge());
				statement.setLong(3, patient.getPhone());
				statement.setString(4, patient.getDescription());
				
				statement.executeUpdate();

				statement = connection.prepareStatement("");
				ResultSet resultSet = statement.executeQuery();
				resultSet.next();

				patientId = resultSet.getInt(1);

			} 
		catch (SQLException e)
			{
				//throw new TakeCareClinicException("statement not created");
				e.printStackTrace();
			}
		return patientId;
	}
	@Override
	public Patient getPatientById(int id) throws HealthCareException, ClassNotFoundException, SQLException 
	{
		Class.forName("");
		Connection connnection=DriverManager.getConnection("","","");
		Patient p;
		try{
			statement = connection.prepareStatement("");
			statement.setInt(1, id);
			
			ResultSet resultSet = statement.executeQuery();
			resultSet.next();
				p=new Patient();
				p.setPatientId(resultSet.getInt(1));
				p.setPatientname(resultSet.getString(2));
				p.setAge(resultSet.getInt(3));
				p.setPhone(resultSet.getLong(4));
				p.setDescription(resultSet.getString(5));
				p.setConsultationDate(resultSet.getDate(6));
			return p;
		}
		catch(SQLException e)
		{
			throw new HealthCareException("statement not created");
		}	
	}
}
