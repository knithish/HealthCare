package com.capgemini.takehome.dao;

import com.capgemini.takehome.Exception.TakeHomeException;
import com.capgemini.takehome.bean.ProductBean;

public interface IProductDAO {
	
	ProductBean getProductByCode(int code) throws TakeHomeException;
		
	}

