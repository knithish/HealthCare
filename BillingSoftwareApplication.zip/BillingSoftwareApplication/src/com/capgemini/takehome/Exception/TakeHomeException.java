package com.capgemini.takehome.Exception;

public class TakeHomeException extends Exception {
	private String message;

	public TakeHomeException(String message) {
		super();
		this.message = message;
	}

	public String getMessage() {
		return message;
	}
}
