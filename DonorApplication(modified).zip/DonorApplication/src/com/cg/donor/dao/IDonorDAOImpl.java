package com.cg.donor.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.cg.donor.bean.DonorBean;
import com.cg.donor.exception.DonorException;
import com.cg.donor.util.DBConnection;

public class IDonorDAOImpl implements IDonorDAO
{

	@Override
	public String addDonor(DonorBean donor) throws DonorException, IOException
	{
		
				Connection con=DBConnection.getConnection();
				PreparedStatement ps=null;
				ResultSet rs=null;
				String donorId=null;
				int queryResult=0;
				Date sysdate;
		
			try 
			{	
			ps=con.prepareStatement("insert into Donor_Details values(donorId_sequence.nextval,?,?,?,sysdate,?)");
			ps.setString(1, donor.getDonorName());
			ps.setString(2, donor.getAddress());
			ps.setString(3, donor.getDonorNumber());
			ps.setDouble(4, donor.getDonationAmount());
			ps.executeUpdate();
			Statement st=con.createStatement();
			rs=st.executeQuery("select max(donor_id) from Donor_Details");
			if(rs.next())
			{
				donorId=rs.getString(1);
			}
			}
			catch(Exception e)
			{
				System.out.println(e);
			}
		
		return donorId;
	}

	@Override
	public DonorBean viewDonorDetails(String donorId) throws DonorException, IOException 
	{
		DonorBean bean=null;
		Connection con=DBConnection.getConnection();
		
		try 
		{
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select * from Donor_Details where donor_id='"+donorId+"'");
			bean=new DonorBean();
			while(rs.next())
			{
				bean.setDonorId(rs.getString(1));
				bean.setDonorName(rs.getString(2));
				bean.setAddress(rs.getString(3));
				bean.setDonorNumber(rs.getString(4));
				bean.setDonationDate(rs.getDate(5));
				bean.setDonationAmount(rs.getDouble(6));
				
			}
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			System.out.println(e);
		}
		
		
		return bean;
	}

	@Override
	public List retrieveAll() throws DonorException, IOException
	{
		Connection con=DBConnection.getConnection();
		List<DonorBean> li=new ArrayList<>();
		try 
		{
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select * from Donor_Details");
			
			while(rs.next())
			{	
				DonorBean bean=new DonorBean();
				bean.setDonorId(rs.getString(1));
				bean.setDonorName(rs.getString(2));
				bean.setAddress(rs.getString(3));
				bean.setDonorNumber(rs.getString(4));
				bean.setDonationDate(rs.getDate(5));
				bean.setDonationAmount(rs.getDouble(6));
		
				 li.add(bean);
			}
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			System.out.println(e);
		}
		
		
		return li;
	}

}
